package assignment;
import java.util.*;

public class Assignment4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> l=new LinkedList<String>();
		l.add("May");
		l.add("June");
		l.add("July");
		l.add("August");
		l.add("April");
		l.add("November");
		System.out.println(l);
		
		l.addLast("December");
		l.add(0,"January");
		System.out.println(l);
		
		l.add(1,"March");
		l.add(1,"February");
		System.out.println(l);
		
		l.add(8,"September");
		l.add(9,"October");
		System.out.println(l);
		
		l.remove(7);
		l.add(3,"April");
		System.out.println(l);
		
		System.out.println("Odd Months");
		for(int i=0;i<l.size();i+=2) System.out.print(l.get(i)+" ");
		System.out.println();
		
		System.out.println("Even Months");
		for(int i=1;i<l.size();i+=2) System.out.print(l.get(i)+" ");
		System.out.println();
		
		Iterator itr=l.iterator();
		System.out.println("List is:");
        while(itr.hasNext()) {
        	System.out.print(itr.next()+" ");
        }
        System.out.println();
        
        System.out.println(l.peekFirst()+" "+l.peekLast());
        System.out.println(l.get(5));
        l.remove(5);
        
        System.out.println(l.peekFirst()+" "+l.peekLast());
        System.out.println(l);
        System.out.println(l.pollFirst()+" "+l.pollLast());
        System.out.println(l);
	}
}
