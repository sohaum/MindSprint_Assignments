package assignment;
import java.util.*;

public class Assignment3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> a1=new ArrayList<String>(); 
		a1.add("Apple");
		a1.add("Banana");
		a1.add("Mango");
		a1.add("Orange");
		a1.add("Pineapple");
		a1.add("Guava");
		a1.add("Kolkata");
		a1.add("Chennai");
		a1.add("Painting");
		a1.add("Singing");
		System.out.println("Arraylist is "+a1);
		a1.set(9, "Dancing");
		a1.remove("Painting");
		System.out.println(a1.contains("Cricket"));
		
		a1.remove("Chennai");
		a1.remove("Guava");
		System.out.println("Arraylist is "+a1);

		System.out.println("element at position 4 is: "+ a1.get(3));
		System.out.println("element at position 6 is: "+ a1.get(5));
		Collections.reverse(a1);
		a1.add(3,"Kerala");
		a1.add(1,"Mango");
		System.out.println("Arraylist is "+a1);
		System.out.println(a1.subList(2,5));
	}

}
