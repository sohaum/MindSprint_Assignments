package assignment;
class FactorialThread extends Thread {
	private int number;
	FactorialThread(int number,String name) {
		super(name);
		this.number=number;
	}
	private long factorial(int n) {
		long fact=1;
		for(int i=1;i<=n;i++) {
			fact*=i;
		}
		return fact;
	}
	
	public void run() {
		System.out.println(Thread.currentThread().getName()+" Factorial of "+number+"="+factorial(number));
	}
}
class AdditionThread extends Thread {
	private int a,b;
	AdditionThread(int a,int b,String name) {
		super(name);
		this.a=a;
		this.b=b;
	}
	public void run() {
		System.out.println(Thread.currentThread().getName()+" Addition of "+a+"&"+b+"="+(a+b));
	}
}
public class MultiThreadingDemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread t1=new FactorialThread(4,"t1");
		Thread t2=new FactorialThread(6,"t2");
		Thread t3=new AdditionThread(4,5,"t3");
		Thread t4=new AdditionThread(20,10,"t4");
		
		t2.start();
		t4.start();
		t1.start();
		t3.start();
	}

}
 