package assignment;

import java.util.LinkedHashMap;
import java.util.Map;

public class Assignment6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer, String> linkedHashMap = new LinkedHashMap<Integer, String>();
		linkedHashMap.put(1, new String("India"));
        linkedHashMap.put(2, new String("China"));
        linkedHashMap.put(3, new String("Russia"));
        linkedHashMap.put(4, new String("Spain"));
        linkedHashMap.put(5, new String("France"));
        linkedHashMap.put(6, new String("England"));
        linkedHashMap.put(7, new String("Germany"));
        linkedHashMap.put(8, new String("Belgium"));
        linkedHashMap.put(9, new String("Japan"));
        linkedHashMap.put(10, new String("Argentina"));
        
        System.out.println("\nValues of map after iterating over it : ");
        for (Integer key : linkedHashMap.keySet()) {
            System.out.println(key + ":\t" + linkedHashMap.get(key));
        }
        System.out.println();
        System.out.println(linkedHashMap.containsValue("India"));
        System.out.println(linkedHashMap.containsKey(45));
        linkedHashMap.remove(3);
        System.out.println(linkedHashMap);
        
        Map<Integer, String> m = new LinkedHashMap<Integer, String>();
        m.put(11, "WB");
        m.put(12, "TN");
        m.put(13, "PB");
        System.out.println(m);
        
        linkedHashMap.putAll(m);
        System.out.println("After merging the state map into the existing map:\n " + linkedHashMap);
        linkedHashMap.remove(5);
        System.out.println("Map now: "+linkedHashMap);
        System.out.println(linkedHashMap.isEmpty());
        linkedHashMap.clear();
        System.out.println("After clearing the map: " + linkedHashMap);
	}

}
