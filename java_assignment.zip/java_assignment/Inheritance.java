package assignment;

class Product {
	int id=78;
	String name="Amul";
	public void display() {
		System.out.println("ID: "+ id);
		System.out.println("Name: "+ name);
	}
}
class A extends Product {
	int count=50;
	String category="butter";
	public void display() {
		System.out.println("ID: "+ id);
		System.out.println("Name: "+ name);
		System.out.println("Count: "+ count);
		System.out.println("Category: "+ category);
	}
}
class B extends Product {
	int count=90;
	String category="milk";
	public void display() {
		System.out.println("ID: "+ id);
		System.out.println("Name: "+ name);
		System.out.println("Count: "+ count);
		System.out.println("Category: "+ category);
	}
}
class C extends Product {
	int count=56;
	String category="choco";
	public void display() {
		System.out.println("ID: "+ id);
		System.out.println("Name: "+ name);
		System.out.println("Count: "+ count);
		System.out.println("Category: "+ category);
	}
}
class subA extends A {
	int price=30;
	int total_price=price*count;
	public void display() {
		System.out.println("ID: "+ id);
		System.out.println("Name: "+ name);
		System.out.println("Category: "+ category);
		System.out.println("Total Price: "+total_price);
	}
}
class subB extends B {
	int price=10;
	int total_price=price*count;
	public void display() {
		System.out.println("ID: "+ id);
		System.out.println("Name: "+ name);
		System.out.println("Category: "+ category);
		System.out.println("Total Price: "+total_price);
	}
}

public class Inheritance {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product p=new Product();
		p.display();
		System.out.println();
		
		A a=new A();
		a.display();
		System.out.println();
		
		B b=new B();
		b.display();
		System.out.println();
		
		C c=new C();
		c.display();
		System.out.println();
		
		subA sa=new subA();
		sa.display();
		System.out.println();
		
		subB sb=new subB();
		sb.display();
		System.out.println();
	}

}
