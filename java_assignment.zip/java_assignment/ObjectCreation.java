package assignment;

public class ObjectCreation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String t="Delhi";
		String o="Mumbai";
		String k="delhi";
		String y=new String("Mumbai");
		String l=new String("delhi");
		String p=new String("Hello");
		
		System.out.println(o.equals(l));
		System.out.println(o==l);
		System.out.println();
		
		System.out.println(y.equals(p));
		System.out.println(y==p);
		System.out.println();
		
		System.out.println(t.equals(o));
		System.out.println(t==o);
		System.out.println();
		
		System.out.println(k.equals(y));
		System.out.println(k==y);
		System.out.println();
		
		System.out.println(p.equals(y));
		System.out.println(p==y);
		
//		String Pool: “Delhi”, “Mumbai”, “delhi”, “Hello”
//		Heap:  “Mumbai”, “delhi” “Hello” 
	}

}
